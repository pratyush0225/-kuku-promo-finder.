# Manual audit of the rules-only top 20 (single reader, n=20 - noisy; first-pass labels drafted with Claude's help, then to be re-read by the author)
GOOD = could post as-is. OK = right moment, needs a human trim / has a soft hook or ending. BAD = would not post.
Labels were made by reading the script text of each clip (not by watching video - no video was provided).

| rank | ep | label | note |
|---|---|---|---|
| 1 | 15 stitched | GOOD | Opens on Juliana bursting in; skips 30 s of repeated abuse; ends on Alexander vs 3 thugs + cliffhanger sting |
| 2 | 11 | OK | good hook, ending is a protest not an unresolved turn |
| 3 | 2 | GOOD | "I cannot marry you, Juliana." - instantly clear premise |
| 4 | 28 | GOOD | accusation hook, Duchess collapses mid-sentence ("They have been--") |
| 5 | 1 | OK | starts mid-conversation, misses the bride's entrance |
| 6 | 16 | BAD | ends on a tender gaze; tool trusted the script's own "cliffhanger hold" sound cue |
| 7 | 36 | OK | great last line ("What wedding?") but needs show knowledge |
| 8 | 47 | BAD | ends on a humiliation that resolves, no unresolved turn |
| 9 | 27 | OK | |
| 10 | 11 | GOOD | planted-coat reveal, "There it is. Ha!" |
| 11 | 24 | OK | 58 s, long; ends on a defiant promise |
| 12 | 27 | GOOD | "She admits she has been giving the Duchess poison!" |
| 13 | 3 | OK | rescue fight, ends on soft "Are you hurt?" |
| 14 | 3 | GOOD | stranger's defence -> proposal -> congregation gasp -> cliffhanger |
| 15 | 43 | GOOD | "I was told he was dead!" -> "Going somewhere, Lord Sterling?" |
| 16 | 20 | OK | villains plotting, no premise for a newcomer |
| 17 | 43 | GOOD | treason exposed, "I didn't!" |
| 18 | 44 | OK | |
| 19 | 20 | BAD | 24 s of scheming, no hook |
| 20 | 29 | OK | |

Totals: 8 GOOD / 9 OK / 3 BAD  ->  usable (GOOD+OK) 17/20 = 85%, post-as-is 8/20 = 40%.

## Recall check on 7 big story beats (chosen by me from loglines + reading)
Before the episode-end "anchor" fix: 2/7 covered (only Ep1 altar, Ep41 explosion).
After the fix: 6/7 covered (Ep12 ultimatum still missed). NOTE: the fix was motivated by these same misses,
so 6/7 is optimistic - it must be re-measured on a new show.
