# Promo shortlist (69 promos, judge: rules only)

## #1 [A]  Ep 15  00:07.60-00:22.50  +  00:53.50-01:26.00  (47.4s, stitched)
- **Hook:** (action) Juliana bursts through the cottage doorway, her hands wrapped in clean white bandages, freezing in horror at the destruction.
- **Cliffhanger:** Thug With Cap: "What? You want to fight us, veteran?" | (sound) Tense, low dramatic cello swell holding into an abrupt cliffhanger cut.
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold; skips a slower middle to join two beats
- score 0.738 (rank score 0.717) rules={'hook': 0.85, 'cliff': 1.0, 'standalone': 1.0, 'pace': 0.69, 'total': 0.74} flags=['stitched']

```
[00:07.60] (action) Juliana bursts through the cottage doorway, her hands wrapped in clean white bandages, freezing in horror at the destruction.
[00:08.50] JULIANA (Desperate, Alarmed): "Stop! What are you doing?!"
[00:13.00] THUG WITH CAP (Mocking, Smug): "We're clearing this rubbish."
[00:16.40] JULIANA (Furious, Pleading): "Those are medicinal plants!"
[00:20.00] BALD THUG (Callous): "They look like weeds to me."
[00:20.50] (action) The bald thug flings the bouquet into the mud and grinds his heavy boot directly onto the delicate flowers.
```

```
[00:53.50] JULIANA (Broken, Sobbing): "My mother's plants..."
[00:57.30] BALD THUG (Cruel, Laughing): "Look at her! Crying over weeds!"
[01:00.00] JULIANA (Screaming): "Stop!"
[01:00.00] (action) The Tall Thug hoists his heavy wooden club above his head to crush the remaining herbs right before Juliana.
[01:03.50] (action) Alexander storms forward with lethal intensity, dark hair flying, breath misting in the cold, radiating untamed rage.
[01:10.50] JULIANA (Whispered Breath, Stunned): "Alexander..."
[01:16.00] (action) Alexander places himself directly between Juliana and the three thugs, staring them down with cold, deadly intent.
[01:19.00] THUG WITH CAP (Challenging, Arrogant): "What? You want to fight us, veteran?"
[01:24.00] (sound) Tense, low dramatic cello swell holding into an abrupt cliffhanger cut.
```

## #2 [A]  Ep 11  00:14.30-00:46.30  (32.0s)
- **Hook:** Juliana: "You have already taken enough from me. Leave!"
- **Cliffhanger:** Juliana: "You cannot simply invade our home because this man makes an accusation!"
- **Why:** opens on a strong line/action; easy to follow cold; tight, back-and-forth pacing
- score 0.707 (rank score 0.692) rules={'hook': 0.62, 'cliff': 0.58, 'standalone': 1.0, 'pace': 1.0, 'total': 0.71} flags=[]

```
[00:14.40] JULIANA (Furious, Defiant): "You have already taken enough from me. Leave!"
[00:16.80] GERALD (Aggressive, Snarl): "Your husband stole my gold pocket watch!"
[00:19.00] JULIANA (Incredulous, Gasping): "What? When?"
[00:20.90] GERALD (Cold, Certain): "The last time I came here."
[00:23.00] JULIANA (Contemptuous, Outraged): "You never even entered the cottage!"
[00:25.20] GERALD (Smug, Threatening): "Then you should have nothing to fear from a search."
[00:27.30] JULIANA (Adamant, Protective): "Alexander would never steal from you."
[00:29.30] GERALD (Mocking, Spiteful): "Of course you would defend him. You married a beggar!"
[00:33.00] ALEXANDER (Low, Menacing): "Choose your next words carefully."
[00:35.10] GERALD (Shouting, Dramatic): "You hear that? He threatens me again!"
[00:37.40] CONSTABLE (Authoritative, Stern): "I have received a complaint of theft."
[00:39.70] JULIANA (Fierce): "A complaint is not proof."
[00:41.40] CONSTABLE (Cold, Procedural): "Then a search will settle the matter."
[00:43.50] JULIANA (Desperate, Shouting): "You cannot simply invade our home because this man makes an accusation!"
```

## #3 [A]  Ep 2  00:00.00-00:27.60  (27.6s)
- **Hook:** The Former Groom: "I cannot marry you, Juliana."
- **Cliffhanger:** Lady Juliana: "A better choice? Is that what she is?"
- **Why:** opens on a strong line/action; easy to follow cold; tight, back-and-forth pacing
- score 0.681 (rank score 0.68) rules={'hook': 0.77, 'cliff': 0.6, 'standalone': 0.88, 'pace': 0.96, 'total': 0.68} flags=['refers-to-absent:Gerald']

```
[00:00.00] THE FORMER GROOM (Cold, Callous): "I cannot marry you, Juliana."
[00:02.80] (action) Juliana gasps softly in heartbreak, her eyes wide and brimming with tears.
[00:04.70] THE FORMER GROOM (Cruel, Derisive): "You are far too plain..."
[00:06.80] THE FORMER GROOM (Dismissive): "...far too silent..."
[00:09.60] THE FORMER GROOM (Arrogant, Conceited): "...and completely beneath the future I deserve."
[00:12.40] LADY JULIANA (Desperate, Pleading): "Gerald... Look at me."
[00:18.20] LADY JULIANA (Trembling, Betrayed): "You gave me your word before both our families."
[00:20.90] THE FORMER GROOM (Indifferent, Unapologetic): "Promises change when a better choice appears."
[00:24.00] LADY JULIANA (Shattered, Disbelieving): "A better choice? Is that what she is?"
```

## #4 [A]  Ep 28  00:15.20-00:48.00  (32.8s)
- **Hook:** Juliana: "I did not poison her! Look at her eyes, the fever has broken!"
- **Cliffhanger:** Dowager Duchess: "They have been—" | (action) The Duchess collapses back onto the pillows, coughing violently and clutching her chest.
- **Why:** opens on a strong line/action; cuts on an unresolved beat; tight, back-and-forth pacing
- score 0.695 (rank score 0.657) rules={'hook': 0.62, 'cliff': 0.68, 'standalone': 0.76, 'pace': 1.0, 'total': 0.69} flags=['ends-on-interrupted-line', 'refers-to-absent:Catherine,Rupert']

```
[00:15.30] JULIANA (Furious, Defiant): "I did not poison her! Look at her eyes, the fever has broken!"
[00:18.90] BLOND NOBLEMAN (Sardonic, Chilling): "A clever story, girl."
[00:20.40] BLOND NOBLEMAN (Threatening): "But the guards know how to extract the truth."
[00:24.80] DOWAGER DUCHESS (Weak, Straining): "Rupert..."
[00:26.70] DOWAGER DUCHESS (Commanding): "Stop this!"
[00:28.80] DOWAGER DUCHESS (Desperate, Firm): "She is innocent."
[00:30.80] DOWAGER DUCHESS (Adamant): "She saved me!"
[00:33.20] JULIANA (Breathless, Relieved): "Your Grace..."
[00:35.00] DOWAGER DUCHESS (Trembling, Shouting): "I know what happened to me!"
[00:38.20] DOWAGER DUCHESS (Fierce, Condemning): "I was poisoned!"
[00:40.30] DOWAGER DUCHESS (Accusing): "And you... you knew!"
[00:43.60] DOWAGER DUCHESS (Choking, Weakening): "Catherine knew!"
[00:45.60] DOWAGER DUCHESS (Gasping): "They have been—"
[00:46.80] (action) The Duchess collapses back onto the pillows, coughing violently and clutching her chest.
```

## #5 [A]  Ep 1  01:14.60-01:47.30  (32.7s)
- **Hook:** Lady In Gold Gown: "Long enough to know he was never going to marry you."
- **Cliffhanger:** Lady Juliana: "And I am what?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.653 (rank score 0.653) rules={'hook': 0.54, 'cliff': 0.55, 'standalone': 0.88, 'pace': 0.92, 'total': 0.65} flags=['refers-to-absent:Clarissa']

```
[01:15.00] LADY IN GOLD GOWN (Cruel, Poised): "Long enough to know he was never going to marry you."
[01:19.00] (action) Juliana turns abruptly toward the first row of pews, where her elderly father sits gripping an ornate brass cane.
[01:20.10] LADY JULIANA (Desperate): "Father..."
[01:21.40] LADY JULIANA (Begging): "Tell them this is a mistake."
[01:26.00] LADY JULIANA (Choking, Broken): "Father... please look at me."
[01:29.50] (action) The father tightens his jaw and stony expression, refusing to offer a single word or look.
[01:30.90] MATRIARCH (Stern, Resolute): "Enough!"
[01:32.10] MATRIARCH (Disgusted): "You have embarrassed this family long enough."
[01:36.20] LADY JULIANA (Incredulous): "Embarrassed you?"
[01:38.80] MATRIARCH (Haughty): "Clarissa knows how to carry herself."
[01:41.60] MATRIARCH (Proud): "She has beauty, connections, and a future worth protecting."
[01:45.40] LADY JULIANA (Raw, Painful): "And I am what?"
```

## #6 [A]  Ep 16  00:55.20-01:23.19  (28.0s)
- **Hook:** (action) The Thug with Cap scrambles to his feet and sprints into the dark woods alongside his two limping accomplices.
- **Cliffhanger:** Alexander: "No." | (sound) Slow, resonant emotional cello melody swelling to a dramatic cliffhanger hold.
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold
- score 0.663 (rank score 0.643) rules={'hook': 0.62, 'cliff': 0.7, 'standalone': 1.0, 'pace': 0.56, 'total': 0.66} flags=['script-marks-cliffhanger']

```
[00:55.50] (action) The Thug with Cap scrambles to his feet and sprints into the dark woods alongside his two limping accomplices.
[00:56.00] THUG WITH CAP (Shouting, Retreating): "We were only paid to destroy the garden, that's all!"
[01:00.00] (action) Alexander flexes his bleeding hand, showing no sign of pain.
[01:04.20] JULIANA (Soft, Astounded): "You knew exactly what to do."
[01:07.80] JULIANA (Wondering, Intrigued): "You fought like you've done this a hundred times."
[01:11.00] ALEXANDER (Somber, Heavy-Hearted): "A soldier learns things he wishes he could forget."
[01:14.80] JULIANA (Tender, Concerned): "Are you hurt?"
[01:16.00] (action) Juliana reaches out toward his injured hand with delicate concern.
[01:17.80] ALEXANDER (Quiet, Steady): "No."
[01:18.80] (action) Alexander and Juliana gaze deeply into each other's eyes, an unspoken bond forming between them as the ruined garden lies silent beneath the moon.
[01:20.00] (sound) Slow, resonant emotional cello melody swelling to a dramatic cliffhanger hold.
```

## #7 [A]  Ep 36  01:57.00-02:28.00  (31.0s)
- **Hook:** Alexander: "You told them the truth!"
- **Cliffhanger:** Alexander: "What wedding?"
- **Why:** opens on a strong line/action; easy to follow cold; tight, back-and-forth pacing
- score 0.688 (rank score 0.639) rules={'hook': 0.62, 'cliff': 0.58, 'standalone': 0.88, 'pace': 1.0, 'total': 0.69} flags=['refers-to-absent:Juliana']

```
[01:57.50] ALEXANDER (Furious): "You told them the truth!"
[01:59.80] ALEXANDER'S MOTHER (Agonized): "They called her a witch!"
[02:03.80] ALEXANDER (Horrified): "Juliana... is in a cell?"
[02:07.80] ALEXANDER'S MOTHER (Weak, Trembling): "She was taken before a magistrate."
[02:10.90] ALEXANDER (Barking): "And?!"
[02:12.20] ALEXANDER'S MOTHER (Weeping): "They condemned her."
[02:14.50] ALEXANDER (Gasping): "No."
[02:16.00] ALEXANDER'S MOTHER (Solemn, Shattered): "She is to be executed."
[02:20.20] ALEXANDER (Guttural, Demanding): "When?"
[02:23.20] ALEXANDER'S MOTHER (Trembling): "After the wedding."
[02:26.50] ALEXANDER (Cold, Menacing): "What wedding?"
```

## #8 [A]  Ep 47  01:03.50-01:44.50  (41.0s)
- **Hook:** Catherine: "London closed its doors! My family disowned me!"
- **Cliffhanger:** Catherine: "You expect me to scrub floors before these commoners?"
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold; tight, back-and-forth pacing
- score 0.705 (rank score 0.639) rules={'hook': 0.62, 'cliff': 0.68, 'standalone': 0.85, 'pace': 0.97, 'total': 0.7} flags=['5-speakers']

```
[01:03.50] CATHERINE (Sobbing, Pleading): "London closed its doors! My family disowned me!"
[01:07.20] LADY ASHBOURNE (Cold, Unforgiving): "She aided the poison in my veins. Cast her into the road."
[01:11.80] VAUGHN (Gruff, Ready): "One command, Your Grace, and I drag her past the gates."
[01:15.20] ALEXANDER (Furious, Decisive): "Do it, Vaughn! Throw her past the estate perimeter!"
[01:18.80] CATHERINE (Hysterical, Screaming): "Please, Alexander! Have mercy!"
[01:22.20] JULIANA (Clear, Authoritative): "Stop."
[01:24.00] ALEXANDER (Indignant, Protective): "Juliana, she tried to destroy you!"
[01:26.70] JULIANA (Calm, Composed): "She did."
[01:28.20] JULIANA (Dignified, Principled): "But Ashbourne does not throw beggars into the mud."
[01:31.00] (action) Juliana walks to a side bench, picks up a rough servant's apron and a heavy iron ring of keys, and turns back to face Catherine.
[01:31.50] JULIANA (Steely, Direct): "If you seek shelter in this house, Catherine, you earn it."
[01:36.00] CATHERINE (Incredulous, Stunned): "You want me? As a guest?"
[01:39.20] JULIANA (Unflinching, Firm): "As a scullery maid."
[01:41.50] CATHERINE (Outraged, Venomous): "You expect me to scrub floors before these commoners?"
```

## #9 [A]  Ep 27  00:37.80-01:20.50  (42.7s)
- **Hook:** Dowager Duchess: "Did your husband serve beside him?"
- **Cliffhanger:** Lady Catherine: "Who permitted you to give medicine to the Duchess?"
- **Why:** opens on a strong line/action; easy to follow cold; tight, back-and-forth pacing
- score 0.673 (rank score 0.637) rules={'hook': 0.57, 'cliff': 0.58, 'standalone': 1.0, 'pace': 0.79, 'total': 0.67} flags=[]

```
[00:37.80] DOWAGER DUCHESS (Pleading): "Did your husband serve beside him?"
[00:41.00] JULIANA (Soft, Reverent): "He never spoke of his officers. He only spoke of survival."
[00:44.50] DOWAGER DUCHESS (Hushed, Desperate): "What is your husband's name?"
[00:46.40] (sound) Loud, violent pounding echoes on the wooden double doors.
[00:48.80] (action) The heavy mahogany double doors burst open, revealing the Blond Nobleman flanked by Lady Catherine and a royal guard in uniform.
[00:52.20] LADY CATHERINE (Sharp, Accusatory): "What is that maid doing in Her Grace's private chamber?"
[00:56.80] JULIANA (Calm, Defiant): "She needed help."
[01:00.00] LADY CATHERINE (Piercing, Suspicious): "What are you hiding?"
[01:02.20] JULIANA (Firm): "Nothing."
[01:04.80] LADY CATHERINE (Demanding, Harsh): "Show me your hand."
[01:06.60] BLOND NOBLEMAN (Cold, Authoritative): "Girl. Show me what you are holding."
[01:12.60] BLOND NOBLEMAN (Skeptical): "What is this?"
[01:13.80] JULIANA (Steady): "Medicine."
[01:15.20] LADY CATHERINE (Mocking, Condescending): "Medicine? You are a new maid."
[01:18.10] LADY CATHERINE (Incredulous, Accusing): "Who permitted you to give medicine to the Duchess?"
```

## #10 [A]  Ep 11  01:01.80-01:52.75  (51.0s)
- **Hook:** Juliana: "Please! There is nothing here!"
- **Cliffhanger:** Gerald: "There it is. Ha!"
- **Why:** opens on a strong line/action; easy to follow cold
- score 0.627 (rank score 0.614) rules={'hook': 0.62, 'cliff': 0.55, 'standalone': 1.0, 'pace': 0.68, 'total': 0.63} flags=['dead-air-11s']

```
[01:01.80] JULIANA (Crying, Desperate): "Please! There is nothing here!"
[01:03.90] CONSTABLE (Cold, Indifferent): "Then you have nothing to fear."
[01:06.00] JULIANA (Heartbroken, Sobbing): "Those are all I have left!"
[01:07.50] GERALD (Cruel, Condescending): "Stand aside. Look at this place. A perfect hiding hole for a thief."
[01:12.10] JULIANA (Furious, Accusatory): "You planted this accusation because you cannot bear that I am happy without you!"
[01:15.50] GERALD (Scoffing, Sinister): "Happy?"
[01:21.30] GERALD (Provoking, Smirking): "What is it, soldier? Going to strike a gentleman in front of his wife?"
[01:24.20] JULIANA (Whispering, Terrified): "Don't!"
[01:26.00] ALEXANDER (Haunted, Resolute): "One blow would end this."
[01:28.00] ALEXANDER (Pained, Selfless): "But one blow would destroy her life."
[01:31.00] (action) The Constable grabs the coat by the collar and begins rummaging through its deep pockets.
[01:32.10] JULIANA (Startled, Shouting): "That is his coat!"
[01:35.80] (sound) Metallic clinking of the gold chain sliding against fabric.
[01:37.20] (action) Juliana draws a sharp, terrified breath as her face pales completely.
[01:44.20] GERALD (Gloating, Victorious): "There it is. Ha!"
```

## #11 [B]  Ep 24  00:33.80-01:31.50  (57.7s)
- **Hook:** (action) Juliana gasps in pain, clutching her stomach and bending over as she absorbs the brutal strike.
- **Cliffhanger:** Lady Juliana: "I will return. You cannot stop the healer." | (action) Juliana raises her head. Smudges of dark soot stain her fair cheek, but her piercing blue eyes burn with unwavering defiance and unyielding resolve as she stares toward the hallway.
- **Why:** opens on a strong line/action; easy to follow cold; tight, back-and-forth pacing
- score 0.64 (rank score 0.61) rules={'hook': 0.65, 'cliff': 0.6, 'standalone': 1.0, 'pace': 0.84, 'total': 0.64} flags=[]

## #12 [B]  Ep 27  01:32.80-02:08.40  (35.6s)
- **Hook:** Juliana: "The physicians were not saving her!"
- **Cliffhanger:** Lady Catherine: "She admits she has been giving the Duchess poison in secret!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.641 (rank score 0.607) rules={'hook': 0.5, 'cliff': 0.53, 'standalone': 1.0, 'pace': 0.92, 'total': 0.64} flags=[]

## #13 [B]  Ep 3  00:58.30-01:31.60  (33.3s)
- **Hook:** Noble Matriarch: "Guards! Remove her!"
- **Cliffhanger:** The Bearded Stranger: "Are you hurt?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.605 (rank score 0.602) rules={'hook': 0.5, 'cliff': 0.55, 'standalone': 0.85, 'pace': 0.86, 'total': 0.6} flags=['5-speakers', 'dead-air-6s']

## #14 [B]  Ep 3  01:36.50-02:25.75  (49.2s)
- **Hook:** Noble Matriarch: "You cannot interfere in a family matter!"
- **Cliffhanger:** The Bearded Stranger: "Lady Juliana... accept my hand." | (action) Juliana gazes down at her rugged savior, overcome with emotion as the swelling score holds on the cliffhanger.
- **Why:** cuts on an unresolved beat; easy to follow cold
- score 0.594 (rank score 0.592) rules={'hook': 0.5, 'cliff': 0.65, 'standalone': 1.0, 'pace': 0.7, 'total': 0.59} flags=['script-marks-cliffhanger']

## #15 [B]  Ep 43  01:33.20-01:54.96  (21.8s)
- **Hook:** Blond Nobleman: "I was told he was dead!"
- **Cliffhanger:** Police Constable: "Going somewhere, Lord Sterling?"
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold; tight, back-and-forth pacing
- score 0.641 (rank score 0.586) rules={'hook': 0.62, 'cliff': 0.8, 'standalone': 0.88, 'pace': 0.94, 'total': 0.64} flags=['refers-to-absent:Lord Sterling']

## #16 [B]  Ep 20  01:10.60-01:54.75  (44.2s)
- **Hook:** Seamus: "You are a viscount's daughter!"
- **Cliffhanger:** Catherine: "This house will only bow to me."
- **Why:** cuts on an unresolved beat; easy to follow cold; tight, back-and-forth pacing
- score 0.608 (rank score 0.584) rules={'hook': 0.5, 'cliff': 0.73, 'standalone': 1.0, 'pace': 0.81, 'total': 0.61} flags=['script-marks-cliffhanger']

## #17 [B]  Ep 43  00:24.00-01:12.70  (48.7s)
- **Hook:** Blond Nobleman: "You have all been deceived!"
- **Cliffhanger:** Blond Nobleman: "I didn't!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.638 (rank score 0.584) rules={'hook': 0.5, 'cliff': 0.58, 'standalone': 1.0, 'pace': 0.96, 'total': 0.64} flags=[]

## #18 [B]  Ep 44  00:08.60-00:46.40  (37.8s)
- **Hook:** Lord Sterling: "You have no authority!"
- **Cliffhanger:** Catherine: "You don't remember?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.641 (rank score 0.584) rules={'hook': 0.5, 'cliff': 0.5, 'standalone': 1.0, 'pace': 0.88, 'total': 0.64} flags=[]

## #19 [B]  Ep 20  00:15.20-00:39.20  (24.0s)
- **Hook:** Catherine: "'Practically' is a word for beggars. I do not marry a practical Duke."
- **Cliffhanger:** Catherine: "How much longer can the frail thing survive?"
- **Why:** tight, back-and-forth pacing
- score 0.594 (rank score 0.571) rules={'hook': 0.54, 'cliff': 0.55, 'standalone': 0.76, 'pace': 0.86, 'total': 0.59} flags=['refers-to-absent:Alexander,Old Woman']

## #20 [B]  Ep 29  00:24.80-00:59.00  (34.2s)
- **Hook:** Catherine: "You still call this a legacy?"
- **Cliffhanger:** Juliana: "You are doing this because I saved the Duchess!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.606 (rank score 0.571) rules={'hook': 0.45, 'cliff': 0.43, 'standalone': 1.0, 'pace': 0.99, 'total': 0.61} flags=[]

## #21 [B]  Ep 7  00:32.80-01:09.50  (36.7s)
- **Hook:** Aristocratic Woman: "Home? Look at your hands, Juliana."
- **Cliffhanger:** Gerald: "And your husband?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.577 (rank score 0.57) rules={'hook': 0.45, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.99, 'total': 0.58} flags=[]

## #22 [B]  Ep 32  00:43.40-00:58.00  +  02:15.00-02:34.38  (34.0s, stitched)
- **Hook:** Catherine: "You still think you are better?!"
- **Cliffhanger:** Catherine: "Then let's see how brave you are when it touches your skin!" | (action) Juliana gasps, freezing as the glowing tip of the iron thrusts forward, stopping mere millimeters from her right eye.
- **Why:** opens on a strong line/action; cuts on an unresolved beat; tight, back-and-forth pacing; skips a slower middle to join two beats
- score 0.603 (rank score 0.564) rules={'hook': 0.65, 'cliff': 0.88, 'standalone': 0.76, 'pace': 0.96, 'total': 0.6} flags=['stitched', 'refers-to-absent:Clarissa,Gerald']

## #23 [B]  Ep 16  00:16.80-00:44.20  (27.4s)
- **Hook:** (action) Alexander strikes the thug across the chest and slams him violently into the muddy ground beside the stone wall.
- **Cliffhanger:** Alexander: "Who sent you?" | (action) Alexander lifts the thug onto his tiptoes against the cottage wall, glaring with lethal intensity.
- **Why:** easy to follow cold
- score 0.58 (rank score 0.562) rules={'hook': 0.5, 'cliff': 0.58, 'standalone': 1.0, 'pace': 0.6, 'total': 0.58} flags=['dead-air-6s']

## #24 [B]  Ep 34  01:25.00-01:55.00  (30.0s)
- **Hook:** (action) Lady Juliana slams her cuffed hands against the wooden railing of the dock, her voice ringing out in indignant fury.
- **Cliffhanger:** Lady Juliana: "What were their illnesses?"
- **Why:** opens on a strong line/action; easy to follow cold; tight, back-and-forth pacing
- score 0.603 (rank score 0.562) rules={'hook': 0.55, 'cliff': 0.48, 'standalone': 0.85, 'pace': 0.96, 'total': 0.6} flags=['5-speakers']

## #25 [B]  Ep 12  00:41.80-01:27.21  (45.4s)
- **Hook:** Juliana: "What do you want?"
- **Cliffhanger:** Juliana: "Tell me where the garden is." | (action) Juliana locks eyes with Clarissa without flinching as the scene freezes on her brave, sacrificial defiance.
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.568 (rank score 0.556) rules={'hook': 0.45, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.93, 'total': 0.57} flags=[]

## #26 [B]  Ep 36  02:43.20-03:20.75  (37.6s)
- **Hook:** Alexander'S Mother: "Alexander, you cannot go back there alone!"
- **Cliffhanger:** Alexander: "...their dead Duke is coming home." | (sound) A heavy, ominous orchestral swell builds to a thunderous cliffhanger sting and reverberates into silence.
- **Why:** cuts on an unresolved beat; easy to follow cold; tight, back-and-forth pacing
- score 0.598 (rank score 0.556) rules={'hook': 0.5, 'cliff': 1.0, 'standalone': 0.88, 'pace': 0.76, 'total': 0.6} flags=['script-marks-cliffhanger', 'refers-to-absent:Juliana']

## #27 [B]  Ep 31  01:17.80-01:43.50  (25.7s)
- **Hook:** Catherine: "You call that marriage?"
- **Cliffhanger:** Catherine: "I have beauty, money, family, status! What do you have?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.578 (rank score 0.543) rules={'hook': 0.45, 'cliff': 0.55, 'standalone': 1.0, 'pace': 0.93, 'total': 0.58} flags=[]

## #28 [B]  Ep 1  00:21.80-00:50.00  (28.2s)
- **Hook:** Lady Juliana: "What do you mean?"
- **Cliffhanger:** Lady Juliana: "You knew this before I walked through those doors!"
- **Why:** cuts on an unresolved beat; easy to follow cold
- score 0.542 (rank score 0.542) rules={'hook': 0.45, 'cliff': 0.68, 'standalone': 0.88, 'pace': 0.72, 'total': 0.54} flags=['refers-to-absent:Gerald', 'dead-air-8s']

## #29 [B]  Ep 21  00:31.00-00:42.80  +  01:27.70-01:54.00  (38.1s, stitched)
- **Hook:** (action) Prudence drops desperately to her knees onto the hay-strewn barn floor, clasping her hands in tearful supplication.
- **Cliffhanger:** Prudence: "Inside that massive house with all their wealth, she is fading to nothing, and no one can stop it." | (action) Lady Juliana sits motionless at the rustic wooden table, her bandaged hands holding open her late mother's leather-bound herbal ledger. Her eyes reflect deep apprehension as the dire truth settles over her.
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold; skips a slower middle to join two beats
- score 0.563 (rank score 0.54) rules={'hook': 0.62, 'cliff': 0.7, 'standalone': 0.88, 'pace': 0.68, 'total': 0.56} flags=['stitched', 'refers-to-absent:Dowager Duchess']

## #30 [B]  Ep 4  01:55.00-02:31.40  (36.4s)
- **Hook:** Gerald: "You have thrown yourself away!"
- **Cliffhanger:** (action) Juliana and the Mysterious Bearded Man walk hand-in-hand through the towering doors into the sunlight together, turning their backs on the ruined wedding as the screen fades out.
- **Why:** easy to follow cold
- score 0.542 (rank score 0.539) rules={'hook': 0.5, 'cliff': 0.45, 'standalone': 0.88, 'pace': 0.65, 'total': 0.54} flags=['soft-closure-at-end', 'refers-to-absent:Lady Juliana', 'dead-air-11s']

## #31 [C]  Ep 35  01:51.00-02:37.50  (46.5s)
- **Hook:** Alexander'S Mother: "How did you escape?"
- **Cliffhanger:** (sound) A sudden, ominous orchestral crescendo swells dramatically into silence.
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.579 (rank score 0.539) rules={'hook': 0.45, 'cliff': 0.5, 'standalone': 1.0, 'pace': 0.77, 'total': 0.58} flags=['dead-air-8s']

## #32 [C]  Ep 45  01:08.80-02:01.75  (53.0s)
- **Hook:** Catherine: "Wife?!"
- **Cliffhanger:** (action) Catherine raises her chin, a vindictive smirk spreading across her lips as she realizes her rival's claim has just been torn to pieces.
- **Why:** easy to follow cold
- score 0.59 (rank score 0.537) rules={'hook': 0.52, 'cliff': 0.55, 'standalone': 0.88, 'pace': 0.74, 'total': 0.59} flags=['starts-on-bare-reply', 'refers-to-absent:Lady Juliana', 'dead-air-9s']

## #33 [C]  Ep 44  00:46.60-01:10.50  (23.9s)
- **Hook:** Catherine: "I was supposed to be your Duchess!"
- **Cliffhanger:** Catherine: "Her?!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.586 (rank score 0.534) rules={'hook': 0.5, 'cliff': 0.48, 'standalone': 1.0, 'pace': 0.85, 'total': 0.59} flags=['dead-air-7s']

## #34 [C]  Ep 2  01:09.40-01:50.00  (40.6s)
- **Hook:** The Former Groom: "Go home quietly, Juliana. At least leave this chapel with some dignity."
- **Cliffhanger:** Lady Juliana: "...but I will not leave it believing I was the one who should be ashamed." | (action) Juliana breathes with steady resolve, holding her head high as the solemn orchestral score swells into the final beat.
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.531 (rank score 0.53) rules={'hook': 0.42, 'cliff': 0.58, 'standalone': 0.88, 'pace': 0.79, 'total': 0.53} flags=['refers-to-absent:Gerald']

## #35 [C]  Ep 31  01:50.20-02:40.00  (49.8s)
- **Hook:** Catherine: "[scoffs] Peasants? People?"
- **Cliffhanger:** (action) Juliana recoils back against the hard dungeon wall, gasping for breath in raw terror as the searing iron stops inches from her eyes.
- **Why:** cuts on an unresolved beat; easy to follow cold; tight, back-and-forth pacing
- score 0.565 (rank score 0.53) rules={'hook': 0.45, 'cliff': 0.65, 'standalone': 1.0, 'pace': 0.76, 'total': 0.56} flags=['script-marks-cliffhanger', 'dead-air-9s']

## #36 [C]  Ep 38  00:45.50-01:27.91  (42.4s)
- **Hook:** Juliana: "What if I die here?"
- **Cliffhanger:** Juliana: "Alexander..." | (sound) A sharp, high-tension dramatic swell strikes and echoes out into silence alongside the fading toll of the distant church bells.
- **Why:** opens on a strong line/action; cuts on an unresolved beat
- score 0.568 (rank score 0.525) rules={'hook': 0.57, 'cliff': 0.66, 'standalone': 0.58, 'pace': 0.59, 'total': 0.57} flags=['monologue-or-one-speaker', 'refers-to-absent:Alexander']

## #37 [C]  Ep 45  00:22.90-00:36.80  +  00:43.80-00:59.80  (29.9s, stitched)
- **Hook:** Juliana: "You're the Duke?"
- **Cliffhanger:** Catherine: "I didn't know!"
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold; tight, back-and-forth pacing; skips a slower middle to join two beats
- score 0.577 (rank score 0.525) rules={'hook': 0.57, 'cliff': 0.68, 'standalone': 1.0, 'pace': 0.91, 'total': 0.58} flags=['stitched']

## #38 [C]  Ep 28  01:35.20-02:18.50  (43.3s)
- **Hook:** (action) Juliana gasps in horror, realizing her secret identity has been laid bare.
- **Cliffhanger:** Catherine: "...before he sends you to the gallows."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.555 (rank score 0.524) rules={'hook': 0.4, 'cliff': 0.4, 'standalone': 0.88, 'pace': 0.89, 'total': 0.56} flags=['refers-to-absent:Lady Juliana']

## #39 [C]  Ep 25  00:44.40-01:18.90  (34.5s)
- **Hook:** Alexander: "What were you doing there?"
- **Cliffhanger:** Alexander: "What did you find?"
- **Why:** tight, back-and-forth pacing
- score 0.545 (rank score 0.518) rules={'hook': 0.45, 'cliff': 0.6, 'standalone': 0.76, 'pace': 0.85, 'total': 0.54} flags=['refers-to-absent:Dowager Duchess,Prudence']

## #40 [C]  Ep 46  00:42.80-01:25.50  (42.7s)
- **Hook:** High Priest: "No Crown license was sought, because no one thought to ask leave for a Duke to marry."
- **Cliffhanger:** Juliana: "God married us, Father! You are just angry no one asked you first!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.571 (rank score 0.518) rules={'hook': 0.45, 'cliff': 0.43, 'standalone': 0.88, 'pace': 0.89, 'total': 0.57} flags=['refers-to-absent:Alexander']

## #41 [C]  Ep 33  01:44.20-02:24.00  (39.8s)
- **Hook:** Maid: "She was praying!"
- **Cliffhanger:** Maid: "I never said she was a witch!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.551 (rank score 0.515) rules={'hook': 0.35, 'cliff': 0.35, 'standalone': 1.0, 'pace': 0.96, 'total': 0.55} flags=[]

## #42 [C]  Ep 5  00:18.50-00:56.80  (38.3s)
- **Hook:** Lord Ashcroft: "You leave as no daughter of mine."
- **Cliffhanger:** Juliana: "Barbara, don't!"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.517 (rank score 0.513) rules={'hook': 0.39, 'cliff': 0.33, 'standalone': 1.0, 'pace': 0.94, 'total': 0.52} flags=[]

## #43 [C]  Ep 50  00:26.50-00:56.50  (30.0s)
- **Hook:** Catherine: "That's not absolution, Thomas. That's a fortune."
- **Cliffhanger:** Catherine: "In another room no one uses?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.566 (rank score 0.509) rules={'hook': 0.42, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.87, 'total': 0.57} flags=[]

## #44 [C]  Ep 9  00:05.50-00:45.60  (40.1s)
- **Hook:** Peasant Mother: "Please! They told me there was a woman here who knows herbs. My boy is burning with fever!"
- **Cliffhanger:** Juliana: "He is not beyond saving."
- **Why:** easy to follow cold
- score 0.515 (rank score 0.507) rules={'hook': 0.35, 'cliff': 0.35, 'standalone': 1.0, 'pace': 0.73, 'total': 0.52} flags=[]

## #45 [C]  Ep 30  00:33.40-01:04.30  (30.9s)
- **Hook:** (action) The Elder Nobleman thrusts the gold knob of his walking stick directly against Rupert's chest, pinning him against the wall.
- **Cliffhanger:** Rupert: "The law?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.536 (rank score 0.504) rules={'hook': 0.37, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.83, 'total': 0.54} flags=['starts-mid-sentence']

## #46 [C]  Ep 18  01:05.50-01:16.80  +  02:38.00-03:12.00  (45.3s, stitched)
- **Hook:** (action) Alexander points upward with urgency, pulling her under his arm.
- **Cliffhanger:** Juliana: "What are you going to do?"
- **Why:** opens on a strong line/action; cuts on an unresolved beat; easy to follow cold; skips a slower middle to join two beats
- score 0.517 (rank score 0.499) rules={'hook': 0.55, 'cliff': 0.83, 'standalone': 1.0, 'pace': 0.61, 'total': 0.52} flags=['stitched']

## #47 [C]  Ep 48  00:02.40-00:32.00  (29.6s)
- **Hook:** Catherine: "Two words, and that healer's crown rolls right back into the gutter where it belongs."
- **Cliffhanger:** Catherine: "Lock it."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.55 (rank score 0.497) rules={'hook': 0.42, 'cliff': 0.43, 'standalone': 0.88, 'pace': 0.79, 'total': 0.55} flags=['refers-to-absent:Alexander']

## #48 [C]  Ep 13  00:24.20-00:52.60  (28.4s)
- **Hook:** Alexander: "I would rather face the gallows than watch you hurt yourself for me."
- **Cliffhanger:** Alexander: "Please..."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.508 (rank score 0.496) rules={'hook': 0.3, 'cliff': 0.31, 'standalone': 1.0, 'pace': 0.93, 'total': 0.51} flags=['ends-on-sad-beat']

## #49 [C]  Ep 32  01:11.30-01:47.20  (35.9s)
- **Hook:** Catherine: "You were rejected!"
- **Cliffhanger:** Juliana: "And a woman who never embarrasses the people standing behind her."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.529 (rank score 0.496) rules={'hook': 0.35, 'cliff': 0.35, 'standalone': 1.0, 'pace': 0.82, 'total': 0.53} flags=[]

## #50 [C]  Ep 25  01:45.20-02:08.00  (22.8s)
- **Hook:** Alexander: "You treated her?"
- **Cliffhanger:** Juliana: "Alexander... why are you so angry?"
- **Why:** easy to follow cold
- score 0.521 (rank score 0.495) rules={'hook': 0.45, 'cliff': 0.5, 'standalone': 0.88, 'pace': 0.75, 'total': 0.52} flags=['refers-to-absent:Prudence']

## #51 [C]  Ep 23  01:13.80-02:11.20  (57.4s)
- **Hook:** Prudence: "What are you saying?"
- **Cliffhanger:** (sound) Loud, metallic clack of the door latch turning, followed by the slow creak of wood hinges.
- **Why:** easy to follow cold
- score 0.518 (rank score 0.494) rules={'hook': 0.45, 'cliff': 0.55, 'standalone': 1.0, 'pace': 0.68, 'total': 0.52} flags=['dead-air-8s']

## #52 [C]  Ep 49  01:43.80-02:24.75  (41.0s)
- **Hook:** Father Thomas: "If I keep the hearing open, if I feed you every word spoken behind those doors, what happens to me when the Duke finds out a crowned priest conspired against him?"
- **Cliffhanger:** Catherine: "We always have."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.547 (rank score 0.493) rules={'hook': 0.42, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.75, 'total': 0.55} flags=[]

## #53 [C]  Ep 36  00:52.00-01:25.50  (33.5s)
- **Hook:** Alexander: "While the world mourned a dead heir."
- **Cliffhanger:** Alexander: "What?"
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.529 (rank score 0.492) rules={'hook': 0.39, 'cliff': 0.4, 'standalone': 0.88, 'pace': 0.79, 'total': 0.53} flags=['refers-to-absent:Juliana']

## #54 [C]  Ep 41  00:58.00-01:36.09  (38.1s)
- **Hook:** Juliana: "You needed an entire chapel to feel powerful over one chained woman?"
- **Cliffhanger:** (action) Silhouetted armed figures emerge through the smoke and rubble of the breached doorway. Juliana slowly turns her head, glancing back toward the light.
- **Why:** easy to follow cold
- score 0.527 (rank score 0.484) rules={'hook': 0.45, 'cliff': 0.5, 'standalone': 1.0, 'pace': 0.43, 'total': 0.53} flags=['script-marks-cliffhanger', 'dead-air-17s']

## #55 [C]  Ep 26  00:56.00-01:07.00  +  01:36.00-02:00.88  (35.9s, stitched)
- **Hook:** Dowager Duchess: "Rupert and Catherine want me dead. They are poisoning me in my own bed, aren't they?"
- **Cliffhanger:** Dowager Duchess: "Where... where... Where did you get this ring? Speak to me!"
- **Why:** opens on a strong line/action; cuts on an unresolved beat; skips a slower middle to join two beats
- score 0.507 (rank score 0.481) rules={'hook': 0.57, 'cliff': 0.85, 'standalone': 0.76, 'pace': 0.68, 'total': 0.51} flags=['stitched', 'refers-to-absent:Catherine,Rupert']

## #56 [C]  Ep 22  00:49.20-01:17.50  (28.3s)
- **Hook:** Housekeeper: "She looks soft."
- **Cliffhanger:** Housekeeper: "Then prove it. The manor has no use for useless girls."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.499 (rank score 0.477) rules={'hook': 0.3, 'cliff': 0.3, 'standalone': 1.0, 'pace': 0.84, 'total': 0.5} flags=['low-confidence']

## #57 [C]  Ep 42  00:30.40-01:17.50  (47.1s)
- **Hook:** Blond Nobleman: "You cannot be him. Alexander died!"
- **Cliffhanger:** Alexander: "And now, Rupert... we settle what you stole."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.521 (rank score 0.477) rules={'hook': 0.5, 'cliff': 0.4, 'standalone': 0.88, 'pace': 0.78, 'total': 0.52} flags=['refers-to-absent:Rupert']

## #58 [C]  Ep 33  00:44.20-01:15.00  (30.8s)
- **Hook:** Lord: "Did she prepare things no physician had prescribed?"
- **Cliffhanger:** Lord: "Then help him."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.509 (rank score 0.476) rules={'hook': 0.3, 'cliff': 0.33, 'standalone': 1.0, 'pace': 0.98, 'total': 0.51} flags=[]

## #59 [C]  Ep 35  00:59.50-01:33.20  (33.7s)
- **Hook:** Alexander'S Mother: "They told me you died. They told me your entire regiment was destroyed."
- **Cliffhanger:** Alexander: "Yes."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.506 (rank score 0.471) rules={'hook': 0.3, 'cliff': 0.33, 'standalone': 1.0, 'pace': 0.96, 'total': 0.51} flags=[]

## #60 [C]  Ep 46  01:40.50-02:23.80  (43.3s)
- **Hook:** Alexander: "A Duke's marriage is judged by the Crown's peerage court, not by a parish priest's seal."
- **Cliffhanger:** Catherine: "Ten days is plenty of time."
- **Why:** easy to follow cold; tight, back-and-forth pacing
- score 0.517 (rank score 0.47) rules={'hook': 0.3, 'cliff': 0.3, 'standalone': 1.0, 'pace': 0.96, 'total': 0.52} flags=[]

## #61 [C]  Ep 47  00:23.20-00:59.80  (36.6s)
- **Hook:** Juliana: "What if Father Thomas sways the High Council?"
- **Cliffhanger:** Lady Ashbourne: "You dare show your face in Ashbourne courtyard?"
- **Why:** easy to follow cold
- score 0.515 (rank score 0.467) rules={'hook': 0.45, 'cliff': 0.4, 'standalone': 0.88, 'pace': 0.7, 'total': 0.52} flags=['refers-to-absent:Father Thomas']

## #62 [C]  Ep 6  00:29.20-01:13.20  (44.0s)
- **Hook:** Juliana: "At least no one there will be waiting to humiliate me."
- **Cliffhanger:** Juliana: "If I stop now, I will think about everything I lost."
- **Why:** easy to follow cold
- score 0.46 (rank score 0.455) rules={'hook': 0.3, 'cliff': 0.33, 'standalone': 1.0, 'pace': 0.66, 'total': 0.46} flags=['dead-air-8s', 'low-confidence']

## #63 [C]  Ep 8  00:15.00-01:02.80  (47.8s)
- **Hook:** Juliana: "How do you know that?"
- **Cliffhanger:** Juliana: "And the scars... were they from the war?"
- **Why:** easy to follow cold
- score 0.458 (rank score 0.451) rules={'hook': 0.3, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.74, 'total': 0.46} flags=['low-confidence']

## #64 [C]  Ep 37  01:53.50-02:36.47  (43.0s)
- **Hook:** Juliana: "They cannot take who I am!"
- **Cliffhanger:** (sound) A deep, ominous cello rumble builds alongside the crackle of the fireplace into an unresolved, tension-filled cliffhanger sting before fading out.
- **Why:** cuts on an unresolved beat; easy to follow cold
- score 0.477 (rank score 0.442) rules={'hook': 0.35, 'cliff': 0.7, 'standalone': 1.0, 'pace': 0.62, 'total': 0.48} flags=['script-marks-cliffhanger', 'dead-air-10s', 'low-confidence']

## #65 [C]  Ep 10  01:03.90-01:34.00  (30.1s)
- **Hook:** Juliana: "Why do you look at me like that?"
- **Cliffhanger:** Alexander: "Your touch is the only medicine that has ever eased my pain."
- **Why:** easy to follow cold
- score 0.433 (rank score 0.425) rules={'hook': 0.3, 'cliff': 0.3, 'standalone': 1.0, 'pace': 0.43, 'total': 0.43} flags=['dead-air-8s', 'low-confidence']

## #66 [C]  Ep 17  00:18.20-00:59.80  (41.6s)
- **Hook:** Juliana: "For standing between me and those men."
- **Cliffhanger:** Alexander: "Of them?"
- **Why:** easy to follow cold
- score 0.432 (rank score 0.418) rules={'hook': 0.3, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.56, 'total': 0.43} flags=['dead-air-7s', 'low-confidence']

## #67 [C]  Ep 40  00:44.10-01:06.80  (22.7s)
- **Hook:** Lord Harrington: "Of the wedding?"
- **Cliffhanger:** Elder Nobleman: "All entrances are covered?"
- **Why:** easy to follow cold
- score 0.45 (rank score 0.414) rules={'hook': 0.42, 'cliff': 0.4, 'standalone': 1.0, 'pace': 0.33, 'total': 0.45} flags=['dead-air-12s', 'low-confidence']

## #68 [C]  Ep 39  01:05.60-01:38.00  (32.4s)
- **Hook:** Alexander: "Today, he comes home."
- **Cliffhanger:** Alexander: "And I am bringing my wife home."
- **Why:** easy to follow cold
- score 0.443 (rank score 0.409) rules={'hook': 0.3, 'cliff': 0.3, 'standalone': 1.0, 'pace': 0.49, 'total': 0.44} flags=['dead-air-9s', 'low-confidence']

## #69 [C]  Ep 19  01:16.50-01:46.20  (29.7s)
- **Hook:** Alexander: "My mother is a prisoner in her own house."
- **Cliffhanger:** Alexander: "Tomorrow, we begin again."
- **Why:** easy to follow cold
- score 0.406 (rank score 0.391) rules={'hook': 0.3, 'cliff': 0.25, 'standalone': 1.0, 'pace': 0.57, 'total': 0.41} flags=['dead-air-8s', 'low-confidence']

