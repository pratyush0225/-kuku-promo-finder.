# 1. Project Documentation

This folder contains all theoretical, architectural, and planning documentation for the Kuku AI Generalist Assignment (Problem 1: Find the Promos).

## Contents

- **`Solution_Doc_Problem1_Find_the_Promos.pdf`**  
  The official 2-page submission document formatted according to Kuku's 5 evaluation lenses:
  1. *Problem Choice & Framing:* Scoping Problem 1, text-only assumption, clean cuts constraint, episode-end hook signal, and early-episode entry weight.
  2. *How it Works:* 5-step pipeline architecture (Code parser → Rules candidate generator → Optional LLM judge → Global ranker → Human reviewer).
  3. *Results on the 50-Episode Pack:* 69 promos across 49 episodes (mean 37.1s, range 21.8s–57.7s): 10 Tier A, 20 Tier B, 39 Tier C. Top ranked promos breakdown (Ep 15 stitched, Ep 11, Ep 2, Ep 28).
  4. *Quality Checking & Honest Failures:* Audit of top 20 (8 Good, 9 OK with trim, 3 Bad), recall check (2/7 increased to 6/7 with episode-ending anchor rule), and failure modes (reads words not visual meaning, trusts script cliffhanger sound cues, starts mid-conversation).
  5. *Scale & Economics:* Zero-cost rules execution in ~0.15s, ~64k input tokens if full LLM judge is active, cached responses.
  6. *AI Tools Used & Honest Miss:* AI used for drafting; caught bug where trailing "..." was misclassified as an interrupted cliffhanger cut-off.

- **`READ_ME_FIRST_Checklist.md`**  
  The step-by-step guidance checklist outlining what was automated and what final review actions are required before form submission.
