# What is done, and what ONLY YOU can do (about 60-90 min)

## Already built (in this folder)
- `code/`  - the tool (no installs needed, Python 3.9+). `code/README.md` explains it.
- `raw_outputs/` - promos.json / .csv / .md from the full 50-episode run, run_log.txt, and audit_top20_labels.md
- `Solution_Doc_Problem1_Find_the_Promos.pdf` - the 2-page doc (limit is 2)
- `Video_Script_3min.md`

## You must do these
1. **Run it yourself once** so you trust it:  `cd code && python run.py "<path to unzipped scripts>" --out outputs`
   then `python check_outputs.py "<path>" outputs/promos.json`.
2. **Run the LLM judge once (important).** I could NOT test it against a real model here - only against a fake server.
   Get a free key (e.g. Google AI Studio / Groq), set `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` (see code/README.md),
   run `python run.py "<path>" --llm --out outputs_llm`. Put `outputs_llm/` beside `raw_outputs/`.
   Then LOOK at it: does #1 now include the Ep 3 proposal? If something breaks or looks wrong, tell me what you see.
   If you can't get it working, submit rules-only and say so (the doc already says the LLM path is untested on a real model).
3. **Re-read the audit labels** (`raw_outputs/audit_top20_labels.md`) and change any label you disagree with - they are
   a first pass drafted with my help. If your numbers change, update section 4 of the PDF.
4. **Make the doc yours.** The assignment says decisions must be yours and they will quiz you. Reword a few sentences,
   and make section 6 true to what YOU did (tools used, one thing the AI got wrong). I can regenerate the PDF if you edit the text.
5. **Confidentiality:** the script pack is Kuku's private content. Do NOT upload the pack or post publicly. Put `code/` in a
   **private** GitHub repo and give Kuku access (or share a Drive link), and share `raw_outputs/` as a Drive folder -
   promos.md quotes script lines. Check every link opens for "anyone with the link" if they ask for that.
6. **Record the video** (optional but recommended) using Video_Script_3min.md.
7. **Submit via the form** within 48 h of the brief: name, roll number (CE23BTECH11042), branch, "Problem 1", links.

## Interview prep: you will run it on a NEW input
- `python run.py <new_folder>` works if the new show uses the same screenplay format. If the format differs, only `parse.py` changes.
- Be able to explain in your own words: why code + LLM split; what "hook score", "cliffhanger score", "weakest-link" mean;
  why windows can't cut a line; what the "episode-end anchor" is and that 6/7 recall was tuned on the same misses.
- Be ready to say what you would do next: video signals, real performance data, cross-episode promos.
- Quick words to edit for a different genre: `code/promo_finder/lexicon.py`. Scoring weights: top of `candidates.py` (`W`).
