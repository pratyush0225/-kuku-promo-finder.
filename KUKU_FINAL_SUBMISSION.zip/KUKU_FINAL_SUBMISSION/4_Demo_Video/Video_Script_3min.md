# 3-minute walkthrough - screen recording, your own voice (Loom / unlisted YouTube / Drive)

**0:00-0:20  The problem.**  "Editors at Kuku watch every episode and hand-pick promos. I built a tool that reads the
screenplay and proposes promos: 20-60 s, a hook in the first 3 s, a cliffhanger at the end, understandable cold."

**0:20-0:50  Show the run.**  Terminal: `python run.py "<scripts folder>"`  -> it prints 50 episodes / 3727 events parsed
and 69 promos in about 2 seconds. Then `python check_outputs.py ...` -> ALL CHECKS PASSED.

**0:50-1:40  Show the output.**  Open `raw_outputs/promos.md`. Scroll to #1 (Ep 15, stitched) and #3 (Ep 2). For each:
read the hook, the cliffhanger, the one-line why. Say: "Every timestamp lands on a real line/beat; none cut a sentence."

**1:40-2:15  How it works.**  One sentence per step: code parses; rules generate and score every valid window;
an optional LLM judges the shortlist and I can swap the model by changing 3 environment variables; code ranks.
"Code guarantees valid timestamps, the model supplies judgement."

**2:15-2:50  Honest failures.**  Open `audit_top20_labels.md`: 8 good / 9 ok / 3 bad. Say the two best failures:
(1) Ep 3 proposal - rules can't read it as a cliffhanger; (2) #6 Ep 16 - tool trusted the script's own "cliffhanger" cue.
Recall: 2/7 big beats at first, 6/7 after my fix - but tuned on the same misses, so optimistic.

**2:50-3:00  Close.**  "Next: run the LLM judge on a real model, add video signals, re-test on a new show."
