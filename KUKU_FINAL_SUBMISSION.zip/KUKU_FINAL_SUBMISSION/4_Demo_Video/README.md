# 4. Demo Video

This folder contains the walkthrough script and guidelines for the optional 3-minute video demonstration required for the assignment.

## Files

- **`Video_Script_3min.md`**  
  A timed, step-by-step speaking script matching the exact structure expected by the evaluation team:
  - `0:00 - 0:20`: The problem & core objective (finding 20–60s promos from screenplay text).
  - `0:20 - 0:50`: Live execution in terminal (`python run.py ...` and `check_outputs.py ...` -> ALL CHECKS PASSED).
  - `0:50 - 1:40`: Walkthrough of top promos (#1 Ep 15 stitched, #2 Ep 11, #3 Ep 2) highlighting the 0–3s hook and cliffhanger.
  - `1:40 - 2:15`: Architectural breakdown (Code parses and guarantees valid boundaries; optional LLM supplies judgement).
  - `2:15 - 2:50`: Honest discussion of failures and limitations (manual audit results, Ep 3 proposal cliffhanger miss, Ep 16 tender gaze).
  - `2:50 - 3:00`: Next steps (multimodal video signals, real performance feedback).

## How to Record and Submit

1. **Recording Tool:** You can use [Loom](https://www.loom.com), Mac QuickTime Player (`File > New Screen Recording`), or OBS Studio.
2. **Delivery Format:**
   - Place your exported video file (`demo_walkthrough.mp4`) into this folder, **OR**
   - Provide an unlisted YouTube, Loom, or Google Drive link directly inside your submission doc or submission form.
