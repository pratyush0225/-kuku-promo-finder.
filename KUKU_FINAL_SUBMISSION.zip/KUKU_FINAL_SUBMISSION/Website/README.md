# 5. Website Prototype

This folder contains a standalone web dashboard application that fulfills the prototype requirement for Problem 1.

## Why a Standalone Dashboard?
In production, marketing editors need to quickly review, filter, and audit proposed promo candidates without manually opening raw JSON or CSV files. This application provides a modern, responsive UI to explore and inspect every candidate clip.

## Quick Start (Zero External Libraries)
The application runs directly on Python's built-in standard library (`http.server`):

```bash
python3 app.py 8000
```
Then open your browser to: **[http://localhost:8000](http://localhost:8000)**

## Key Features
1. **Interactive Tier Filtering:** Toggle between All (69), Tier A (10 Top Promos), Tier B (20), Tier C (39), or Stitched clips only.
2. **Instant Search:** Search in real-time by episode number (e.g. `Ep 15`, `Ep 2`), character names (`Juliana`, `Alexander`, `Gerald`), or spoken quotes.
3. **Structured Review Cards:**
   - Exact segment timestamps and duration (e.g., `00:07.60 - 00:22.50 + 00:53.50 - 01:26.00 (47.4s)`).
   - High-contrast visual cards for the **0–3s Hook**, **Cliffhanger ending**, and **Why it works** rationale.
   - Quality indicators: Composite rank score, raw score, and diagnostic flags.
