"""Interactive Web Application for Kuku Promo Finder.

Serves an interactive dark-mode dashboard with zero external dependencies (Python standard library only).
Allows users to explore discovered promos, filter by tier, search episodes, inspect dialogue/action beats,
and run the discovery pipeline directly.

Usage:
    python app.py [--port 8000]
"""

import os
import sys
import json
import http.server
import socketserver
import urllib.parse
from typing import Dict, Any

PORT = 8000
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.abspath(os.path.join(BASE_DIR, ".."))
OUTPUTS_DIR = os.path.join(PROJECT_DIR, "outputs")
RAW_OUTPUTS_DIR = os.path.join(PROJECT_DIR, "raw_outputs")

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kuku Promo Finder — AI Microdrama Discovery</title>
  <style>
    :root {
      --bg: #0e1117;
      --card-bg: #161b22;
      --card-border: #30363d;
      --primary: #f0883e;
      --accent: #58a6ff;
      --success: #3fb950;
      --text: #c9d1d9;
      --text-bright: #f0f6fc;
      --muted: #8b949e;
      --tier-a: #e3b341;
      --tier-b: #58a6ff;
      --tier-c: #8b949e;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.5;
      padding: 24px;
    }
    .header {
      max-width: 1200px;
      margin: 0 auto 28px;
      padding-bottom: 20px;
      border-bottom: 1px solid var(--card-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }
    .header h1 {
      color: var(--text-bright);
      font-size: 26px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .header p {
      color: var(--muted);
      font-size: 14px;
      margin-top: 4px;
    }
    .badge-pill {
      background: rgba(240, 136, 62, 0.15);
      color: var(--primary);
      border: 1px solid var(--primary);
      padding: 4px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    }
    .stats-bar {
      max-width: 1200px;
      margin: 0 auto 24px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 12px;
    }
    .stat-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 14px 18px;
    }
    .stat-val {
      font-size: 24px;
      font-weight: 700;
      color: var(--text-bright);
    }
    .stat-lbl {
      font-size: 12px;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .controls {
      max-width: 1200px;
      margin: 0 auto 24px;
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
    }
    .search-box {
      flex: 1;
      min-width: 260px;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      color: var(--text-bright);
      padding: 10px 14px;
      border-radius: 6px;
      font-size: 14px;
    }
    .filter-btn {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      color: var(--text);
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 13px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.2s;
    }
    .filter-btn.active, .filter-btn:hover {
      background: var(--card-border);
      color: var(--text-bright);
      border-color: var(--muted);
    }
    .grid {
      max-width: 1200px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 1fr;
      gap: 16px;
    }
    .promo-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 20px;
      transition: transform 0.15s, border-color 0.15s;
    }
    .promo-card:hover {
      border-color: #58a6ff;
    }
    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      flex-wrap: wrap;
      gap: 8px;
    }
    .rank-tag {
      font-size: 16px;
      font-weight: 700;
      color: var(--text-bright);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .tier-badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
    }
    .tier-A { background: rgba(227, 179, 65, 0.2); color: var(--tier-a); border: 1px solid var(--tier-a); }
    .tier-B { background: rgba(88, 166, 255, 0.2); color: var(--tier-b); border: 1px solid var(--tier-b); }
    .tier-C { background: rgba(139, 148, 158, 0.2); color: var(--tier-c); border: 1px solid var(--tier-c); }
    .timing {
      font-family: ui-monospace, SFMono-Regular, SF Mono, Menlo, monospace;
      font-size: 13px;
      color: var(--accent);
      background: #0d1117;
      padding: 4px 8px;
      border-radius: 4px;
      border: 1px solid #21262d;
    }
    .field {
      margin-bottom: 10px;
      font-size: 14px;
    }
    .field-title {
      font-weight: 600;
      color: var(--muted);
      margin-right: 6px;
      display: inline-block;
      min-width: 90px;
    }
    .hook-val { color: #ffd33d; font-weight: 500; }
    .cliff-val { color: #f85149; font-weight: 500; }
    .why-val { color: var(--text); font-style: italic; }
    .meta-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 14px;
      padding-top: 12px;
      border-top: 1px solid #21262d;
      font-size: 12px;
      color: var(--muted);
    }
    .stitched-badge {
      background: rgba(187, 128, 179, 0.2);
      color: #d2a8ff;
      border: 1px solid #d2a8ff;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 11px;
      margin-left: 6px;
    }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1>🎬 Kuku Promo Finder <span class="badge-pill">Problem 1 Prototype</span></h1>
      <p>Automated 20–60s Promo Clip Extraction & Ranking across 50 Episodes</p>
    </div>
    <div>
      <span style="font-size: 13px; color: var(--muted); margin-right: 12px;">Candidate Show: <em>I Married a Broken Soldier</em></span>
    </div>
  </div>

  <div class="stats-bar">
    <div class="stat-card">
      <div class="stat-val" id="stat-total">69</div>
      <div class="stat-lbl">Promos Discovered</div>
    </div>
    <div class="stat-card">
      <div class="stat-val" id="stat-eps">49</div>
      <div class="stat-lbl">Episodes Covered</div>
    </div>
    <div class="stat-card">
      <div class="stat-val" id="stat-mean">37.1s</div>
      <div class="stat-lbl">Mean Clip Duration</div>
    </div>
    <div class="stat-card">
      <div class="stat-val" style="color: var(--tier-a)">10</div>
      <div class="stat-lbl">Tier A (Post First)</div>
    </div>
  </div>

  <div class="controls">
    <input type="text" id="searchInput" class="search-box" placeholder="Search by episode (e.g. Ep 15, Ep 2), quote, or character..." oninput="filterPromos()">
    <button class="filter-btn active" onclick="setTierFilter('ALL', this)">All (69)</button>
    <button class="filter-btn" onclick="setTierFilter('A', this)">Tier A (10)</button>
    <button class="filter-btn" onclick="setTierFilter('B', this)">Tier B (20)</button>
    <button class="filter-btn" onclick="setTierFilter('C', this)">Tier C (39)</button>
    <button class="filter-btn" onclick="toggleStitched(this)">Stitched Only</button>
  </div>

  <div class="grid" id="promosGrid"></div>

  <script>
    let promos = [];
    let currentTier = 'ALL';
    let stitchedOnly = false;

    async function loadData() {
      try {
        const res = await fetch('/api/promos');
        promos = await res.json();
        render();
      } catch (e) {
        console.error(e);
      }
    }

    function setTierFilter(tier, btn) {
      currentTier = tier;
      document.querySelectorAll('.filter-btn').forEach(b => {
        if (!b.innerText.includes('Stitched')) b.classList.remove('active');
      });
      btn.classList.add('active');
      render();
    }

    function toggleStitched(btn) {
      stitchedOnly = !stitchedOnly;
      btn.classList.toggle('active', stitchedOnly);
      render();
    }

    function filterPromos() {
      render();
    }

    function render() {
      const q = document.getElementById('searchInput').value.toLowerCase();
      const container = document.getElementById('promosGrid');
      container.innerHTML = '';

      const filtered = promos.filter(p => {
        if (currentTier !== 'ALL' && p.tier !== currentTier) return false;
        if (stitchedOnly && !p.is_stitched) return false;
        if (!q) return true;
        const text = `ep ${p.episode} ${p.segments_str} ${p.hook} ${p.cliffhanger} ${p.why}`.toLowerCase();
        return text.includes(q);
      });

      document.getElementById('stat-total').innerText = filtered.length;

      filtered.forEach(p => {
        const card = document.createElement('div');
        card.className = 'promo-card';
        card.innerHTML = `
          <div class="card-top">
            <div class="rank-tag">
              #${p.rank}
              <span class="tier-badge tier-${p.tier}">Tier ${p.tier}</span>
              <span style="color: var(--text-bright);">Ep ${p.episode}</span>
              ${p.is_stitched ? '<span class="stitched-badge">Stitched</span>' : ''}
            </div>
            <div class="timing">
              ⏱ ${p.segments_str} (${p.duration_seconds}s)
            </div>
          </div>
          <div class="field">
            <span class="field-title">🪝 Hook (0-3s):</span>
            <span class="hook-val">${escapeHtml(p.hook)}</span>
          </div>
          <div class="field">
            <span class="field-title">⚡ Cliffhanger:</span>
            <span class="cliff-val">${escapeHtml(p.cliffhanger)}</span>
          </div>
          <div class="field">
            <span class="field-title">💡 Why it works:</span>
            <span class="why-val">${escapeHtml(p.why)}</span>
          </div>
          <div class="meta-footer">
            <span>Rank Score: <strong>${p.rank_score}</strong> (Raw: ${p.score})</span>
            <span>Flags: ${p.flags && p.flags.length ? p.flags.join(', ') : 'none'}</span>
          </div>
        `;
        container.appendChild(card);
      });
    }

    function escapeHtml(str) {
      if (!str) return '';
      return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    loadData();
  </script>
</body>
</html>
"""


class RequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/" or parsed.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_TEMPLATE.encode("utf-8"))
        elif parsed.path == "/api/promos":
            json_file = os.path.join(OUTPUTS_DIR, "promos.json")
            if not os.path.exists(json_file):
                json_file = os.path.join(RAW_OUTPUTS_DIR, "promos.json")
            
            if os.path.exists(json_file):
                with open(json_file, "r", encoding="utf-8") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.end_headers()
                self.wfile.write(data.encode("utf-8"))
            else:
                self.send_response(404)
                self.end_headers()
        else:
            super().do_GET()


def run_server(port: int = PORT):
    with socketserver.TCPServer(("", port), RequestHandler) as httpd:
        print("=" * 60)
        print(f"🚀 Kuku Promo Finder Web Dashboard is running!")
        print(f"👉 Open in your browser: http://localhost:{port}")
        print("=" * 60)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down web server...")


if __name__ == "__main__":
    port = PORT
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        port = int(sys.argv[1])
    run_server(port)
