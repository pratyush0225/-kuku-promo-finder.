"""Global ranking and tier assignment for discovered promos."""

from typing import List
from .candidates import PromoCandidate


def rank_and_tier_promos(
    candidates: List[PromoCandidate],
    entry_weight: bool = True,
    max_episodes: int = 50,
) -> List[PromoCandidate]:
    """Calculates final rank scores, sorts globally, and assigns Tiers A, B, and C."""
    for cand in candidates:
        score = cand.total_score
        if entry_weight:
            # Small penalty for later episodes (promos drive viewers to Episode 1)
            # Ep 1 penalty = 0%, Ep 50 penalty = ~10%
            penalty = (cand.episode_num - 1) / (max_episodes - 1) * 0.10 if max_episodes > 1 else 0
            cand.rank_score = round(score * (1.0 - penalty), 3)
        else:
            cand.rank_score = score

        if score < 0.60:
            if "low-confidence" not in cand.flags:
                cand.flags.append("low-confidence")

    # Sort globally by rank_score descending
    candidates.sort(key=lambda c: c.rank_score, reverse=True)

    # Assign tiers
    for idx, cand in enumerate(candidates):
        if idx < 10:
            cand.tier = "A"
        elif idx < 30:
            cand.tier = "B"
        else:
            cand.tier = "C"

    return candidates
