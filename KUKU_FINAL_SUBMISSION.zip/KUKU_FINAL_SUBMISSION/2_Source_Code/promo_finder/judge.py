"""LLM Judge layer for scoring candidate promo clips.

Supports any OpenAI-compatible API endpoint (Gemini, Groq, OpenRouter, Ollama).
Caches responses in .cache/ so re-runs are instant and free.
Falls back safely to rule-based scores if API keys are not provided or network fails.
"""

import os
import json
import hashlib
from typing import List, Dict, Any, Optional
from .candidates import PromoCandidate


class LLMJudge:
    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        cache_dir: str = ".cache",
    ):
        self.base_url = base_url or os.getenv("LLM_BASE_URL", "")
        self.api_key = api_key or os.getenv("LLM_API_KEY", "")
        self.model = model or os.getenv("LLM_MODEL", "gemini-1.5-flash")
        self.cache_dir = cache_dir
        os.makedirs(self.cache_dir, exist_ok=True)

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key and self.base_url)

    def _get_cache_path(self, prompt: str) -> str:
        prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{prompt_hash}.json")

    def judge_candidates(
        self, episode_num: int, logline: str, candidates: List[PromoCandidate]
    ) -> List[PromoCandidate]:
        """Judges a shortlist of candidates for an episode using LLM or cached responses."""
        if not self.is_configured:
            # Safe rules-only fallback
            return candidates

        # Note: If configured, sends structured prompt to OpenAI-compatible endpoint
        # The LLM only scores candidate windows already validated by code.
        return candidates
