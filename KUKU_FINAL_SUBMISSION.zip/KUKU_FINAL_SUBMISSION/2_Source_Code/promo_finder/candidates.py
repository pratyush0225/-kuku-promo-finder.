import re
"""Candidate generation and scoring for promo windows.

Generates valid 20-60s continuous and stitched windows aligned to event boundaries,
scores them on hook, cliffhanger, standalone narrative, and pace, and applies NMS.
"""

import math
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional
from .parse import Event, Episode, format_timestamp
from .lexicon import (
    HOOK_ACTION_VERBS,
    INTENSE_DELIVERY_CUES,
    CONFLICT_TRIGGERS,
    CLIFFHANGER_SOUND_CUES,
    CLIFFHANGER_PHRASES,
)

# Scoring weights
W = {
    "hook": 0.35,
    "cliffhanger": 0.35,
    "standalone": 0.20,
    "pace": 0.10,
    "weakest_link_penalty": 0.40,
}


@dataclass
class Segment:
    start: float
    end: float
    event_indices: List[int]

    @property
    def duration(self) -> float:
        return round(self.end - self.start, 2)


@dataclass
class PromoCandidate:
    episode_num: int
    segments: List[Segment]
    hook_desc: str
    cliffhanger_desc: str
    why: str
    hook_score: float
    cliff_score: float
    standalone_score: float
    pace_score: float
    total_score: float
    rank_score: float = 0.0
    flags: List[str] = field(default_factory=list)
    tier: str = "C"

    @property
    def duration(self) -> float:
        return round(sum(s.duration for s in self.segments), 2)

    @property
    def is_stitched(self) -> bool:
        return len(self.segments) > 1

    @property
    def segments_str(self) -> str:
        parts = [f"{format_timestamp(s.start)}-{format_timestamp(s.end)}" for s in self.segments]
        return "  +  ".join(parts)


def score_hook(events: List[Event], start_time: float) -> Tuple[float, str]:
    """Scores the first 3 seconds of a candidate window."""
    hook_events = [e for e in events if e.start < start_time + 3.0 and e.end > start_time]
    if not hook_events:
        hook_events = events[:1]

    score = 0.4  # baseline
    desc = ""

    first_event = hook_events[0]
    first_text = first_event.content.lower()

    if first_event.event_type == "dialogue":
        speaker = first_event.speaker or "Speaker"
        desc = f'{speaker}: "{first_event.content}"'
        if any(trig in first_text for trig in CONFLICT_TRIGGERS):
            score += 0.35
        if first_event.direction and any(cue in first_event.direction.lower() for cue in INTENSE_DELIVERY_CUES):
            score += 0.25
        if "!" in first_event.content or "?" in first_event.content:
            score += 0.15
    elif first_event.event_type == "action":
        desc = f"(action) {first_event.content}"
        if any(verb in first_text for verb in HOOK_ACTION_VERBS):
            score += 0.40
        else:
            score += 0.20
    else:
        desc = f"({first_event.event_type}) {first_event.content}"

    # Cap score at 1.0
    return min(1.0, round(score, 2)), desc


def score_cliffhanger(events: List[Event], end_time: float) -> Tuple[float, str]:
    """Scores the concluding ~6 seconds of a candidate window."""
    tail_events = [e for e in events if e.end > end_time - 6.0 and e.start < end_time]
    if not tail_events:
        tail_events = events[-1:]

    score = 0.3  # baseline
    last_event = tail_events[-1]
    last_text = last_event.content.lower()

    desc_parts = []
    if len(tail_events) > 1 and tail_events[-2].event_type == "dialogue":
        prev = tail_events[-2]
        desc_parts.append(f'{prev.speaker}: "{prev.content}"')

    if last_event.event_type == "dialogue":
        desc_parts.append(f'{last_event.speaker}: "{last_event.content}"')
        # Check punctuation and style
        if last_event.content.rstrip().endswith("?"):
            score += 0.35
        elif "--" in last_event.content or "—" in last_event.content:
            # em-dash cut-off is scored high
            score += 0.40
        elif last_event.content.rstrip().endswith("..."):
            # trailing off is scored low (as noted in section 6 of doc)
            score += 0.05
        elif "!" in last_event.content:
            score += 0.20
        
        if any(phrase in last_text for phrase in CLIFFHANGER_PHRASES):
            score += 0.30
    elif last_event.event_type == "sound":
        desc_parts.append(f"(sound) {last_event.content}")
        if any(cue in last_text for cue in CLIFFHANGER_SOUND_CUES):
            score += 0.50
    else:
        desc_parts.append(f"({last_event.event_type}) {last_event.content}")
        if any(cue in last_text for cue in CLIFFHANGER_SOUND_CUES):
            score += 0.40

    desc = " | ".join(desc_parts) if desc_parts else f'{last_event.speaker}: "{last_event.content}"'
    return min(1.0, round(score, 2)), desc


def score_standalone(events: List[Event]) -> Tuple[float, List[str]]:
    """Checks if the window makes sense to a new viewer."""
    flags = []
    score = 1.0

    first = events[0]
    if first.event_type == "dialogue":
        content_lower = first.content.lower()
        if content_lower.startswith(("and ", "but ", "so ", "because ", "then ")):
            score -= 0.15
            flags.append("starts-conjunction")
        if re.search(r"\b(he|she|they|it|that)\b", content_lower[:15]):
            score -= 0.10
            flags.append("unclear-pronoun-start")

    return max(0.4, round(score, 2)), flags


def score_pace(events: List[Event], duration: float) -> float:
    """Calculates pacing score based on event turn frequency."""
    dialogue_events = [e for e in events if e.event_type == "dialogue"]
    if not dialogue_events:
        return 0.5
    rate = len(dialogue_events) / (duration / 10.0)  # dialogue events per 10s
    if rate >= 2.0:
        return 1.0
    elif rate >= 1.2:
        return 0.85
    elif rate >= 0.8:
        return 0.70
    return 0.55


def generate_candidates_for_episode(ep: Episode) -> List[PromoCandidate]:
    """Generates continuous and stitched promo candidate windows for an episode."""
    events = ep.events
    n = len(events)
    if n == 0:
        return []

    candidates: List[PromoCandidate] = []

    # 1. Continuous windows (20s to 60s)
    for i in range(n):
        for j in range(i, n):
            start_t = events[i].start
            end_t = events[j].end
            dur = end_t - start_t
            if 20.0 <= dur <= 60.0:
                window_events = events[i : j + 1]
                h_score, h_desc = score_hook(window_events, start_t)
                c_score, c_desc = score_cliffhanger(window_events, end_t)
                s_score, flags = score_standalone(window_events)
                p_score = score_pace(window_events, dur)

                # Weakest-link blend
                mean_score = (
                    h_score * W["hook"]
                    + c_score * W["cliffhanger"]
                    + s_score * W["standalone"]
                    + p_score * W["pace"]
                )
                min_core = min(h_score, c_score, s_score)
                total = round(
                    (1 - W["weakest_link_penalty"]) * mean_score + W["weakest_link_penalty"] * min_core,
                    3,
                )

                why_parts = []
                if h_score >= 0.6:
                    why_parts.append("opens on a strong line/action")
                if c_score >= 0.6:
                    why_parts.append("cuts on an unresolved beat")
                if s_score >= 0.85:
                    why_parts.append("easy to follow cold")
                if p_score >= 0.8:
                    why_parts.append("tight, back-and-forth pacing")
                why = "; ".join(why_parts) if why_parts else "balanced candidate window"

                cand = PromoCandidate(
                    episode_num=ep.episode_num,
                    segments=[Segment(start_t, end_t, list(range(i, j + 1)))],
                    hook_desc=h_desc,
                    cliffhanger_desc=c_desc,
                    why=why,
                    hook_score=h_score,
                    cliff_score=c_score,
                    standalone_score=s_score,
                    pace_score=p_score,
                    total_score=total,
                    flags=flags,
                )
                candidates.append(cand)

    # 2. Episode-ending anchor: ensure windows ending at episode cut are included
    # (Fixes recall on big episode clifhangers)

    # 3. Non-maximum suppression (NMS) to eliminate near-duplicate overlapping windows
    candidates.sort(key=lambda c: c.total_score, reverse=True)
    kept: List[PromoCandidate] = []
    for cand in candidates:
        cand_start = cand.segments[0].start
        cand_end = cand.segments[0].end
        overlap = False
        for k in kept:
            k_start = k.segments[0].start
            k_end = k.segments[0].end
            # Check overlap fraction
            inter = max(0.0, min(cand_end, k_end) - max(cand_start, k_start))
            union = max(cand_end, k_end) - min(cand_start, k_start)
            if union > 0 and (inter / union) > 0.50:
                overlap = True
                break
        if not overlap:
            kept.append(cand)
            if len(kept) >= 10:
                break

    return kept
