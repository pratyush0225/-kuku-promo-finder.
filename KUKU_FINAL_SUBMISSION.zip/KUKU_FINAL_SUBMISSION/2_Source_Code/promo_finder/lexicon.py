"""Genre lexicon and scoring keywords for microdrama promo discovery.

Centralized word lists for hooks, cliffhangers, conflicts, and reveals.
Easily edited for different shows or genres.
"""

# High-impact verbs and actions for the opening 3-second hook
HOOK_ACTION_VERBS = [
    "burst", "bursts", "slap", "slaps", "grab", "grabs", "slam", "slams",
    "collapse", "collapses", "confront", "confronts", "freeze", "freezes",
    "shatter", "shatters", "storm", "storms", "push", "pushes", "shove", "shoves",
    "tear", "tears", "strike", "strikes", "choke", "chokes", "gasp", "gasps",
    "weep", "weeps", "scream", "screams", "shout", "shouts", "draw", "draws"
]

# Intense dialogue cues and emotional delivery directions
INTENSE_DELIVERY_CUES = [
    "furious", "desperate", "alarmed", "screaming", "gasping", "cold, menacing",
    "incredulous", "tearful", "shivering", "venomous", "mocking", "broken",
    "authoritative", "defiant", "outraged", "lethal", "cruel", "thunderous"
]

# High-stakes conflict and dramatic dialogue triggers
CONFLICT_TRIGGERS = [
    "stop", "liar", "cheat", "traitor", "poison", "murder", "kill", "die",
    "betray", "betrayal", "thief", "stole", "steal", "arrest", "leave",
    "never", "divorce", "marry", "wedding", "bastard", "beggar", "refuse",
    "cannot marry", "hand in marriage", "how dare", "what did you do", "enough"
]

# Cliffhanger endings: sound cues, visual cutoffs, unresolved hooks
CLIFFHANGER_SOUND_CUES = [
    "cliffhanger cut", "cliffhanger sting", "cliffhanger", "dramatic cello",
    "ominous cello", "crescendo", "abrupt cut", "cut to black", "abrupt cliffhanger"
]

CLIFFHANGER_PHRASES = [
    "who are you", "what have you done", "is that what", "what wedding",
    "look at me", "choose your next words", "tell me the truth", "answer me",
    "you wouldn't dare", "going somewhere"
]

# Standalone check: character names and contextual references
MAIN_CHARACTERS = {
    "juliana", "alexander", "gerald", "clarissa", "duchess", "matriarch",
    "constable", "sterling", "thug", "thugs"
}
