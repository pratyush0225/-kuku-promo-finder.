"""Screenplay parser for microdrama episodes.

Reads raw screenplay .txt files with timestamped blocks and extracts
structured events with float-second timestamps.
"""

import os
import re
from dataclasses import dataclass, asdict
from typing import List, Optional


def parse_timestamp(ts_str: str) -> float:
    """Converts (mm:ss.xx) or mm:ss.xx to float seconds."""
    ts_str = ts_str.strip().strip("()")
    parts = ts_str.split(":")
    if len(parts) == 2:
        minutes = float(parts[0])
        seconds = float(parts[1])
        return round(minutes * 60 + seconds, 2)
    elif len(parts) == 3:
        hours = float(parts[0])
        minutes = float(parts[1])
        seconds = float(parts[2])
        return round(hours * 3600 + minutes * 60 + seconds, 2)
    return round(float(parts[0]), 2)


def format_timestamp(seconds: float) -> str:
    """Converts float seconds to mm:ss.xx format."""
    mins = int(seconds // 60)
    secs = seconds - (mins * 60)
    return f"{mins:02d}:{secs:05.2f}"


@dataclass
class Event:
    index: int
    scene_num: int
    event_type: str  # 'camera', 'action', 'sound', 'dialogue'
    speaker: Optional[str]
    direction: Optional[str]
    content: str
    start: float
    end: float

    @property
    def duration(self) -> float:
        return round(self.end - self.start, 2)


@dataclass
class Episode:
    episode_num: int
    title: str
    logline: str
    continuity_notes: str
    events: List[Event]

    @property
    def total_duration(self) -> float:
        if not self.events:
            return 0.0
        return max(e.end for e in self.events)


def parse_episode_file(filepath: str) -> Episode:
    """Parses a single screenplay text file into an Episode dataclass."""
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    filename = os.path.basename(filepath)
    # Extract episode number
    ep_num_match = re.search(r"EPISODE\s+NUMBER:\s*(?:Episode\s*)?(\d+)", text, re.IGNORECASE)
    if ep_num_match:
        ep_num = int(ep_num_match.group(1))
    else:
        file_num = re.search(r"episode-?(\d+)", filename, re.IGNORECASE)
        ep_num = int(file_num.group(1)) if file_num else 1

    # Extract logline
    logline_match = re.search(r"EPISODE\s+LOGLINE:\s*(.*?)(?=\n[A-Z\s]+:|\n---|\Z)", text, re.DOTALL | re.IGNORECASE)
    logline = logline_match.group(1).strip().replace("\n", " ") if logline_match else ""

    # Extract continuity notes
    notes_match = re.search(r"CONTINUITY\s+NOTES:\s*(.*?)(?=\n---|\nSCENE|\Z)", text, re.DOTALL | re.IGNORECASE)
    continuity = notes_match.group(1).strip().replace("\n", " ") if notes_match else ""

    # Parse blocks: match Start and End timestamps
    # Handles both upper and lower case headers (e.g. SCENE HEADING vs Scene heading)
    block_pattern = re.compile(
        r"\*\*([^*]+?):?\*\*:?\s*\n"
        r"Start:\s*\(([0-9:.]+)\)\s*\|\s*End:\s*\(([0-9:.]+)\)\s*\n"
        r"(.*?)(?=\n\*\*|\nSCENE\s+\d+|\n---|\Z)",
        re.DOTALL,
    )

    events: List[Event] = []
    current_scene = 1

    # Track scene changes
    scene_markers = list(re.finditer(r"SCENE\s+(\d+)", text, re.IGNORECASE))

    for match in block_pattern.finditer(text):
        header = match.group(1).strip()
        start_str = match.group(2).strip()
        end_str = match.group(3).strip()
        content = match.group(4).strip()

        start_sec = parse_timestamp(start_str)
        end_sec = parse_timestamp(end_str)

        match_pos = match.start()
        for sm in reversed(scene_markers):
            if sm.start() <= match_pos:
                try:
                    current_scene = int(sm.group(1))
                except ValueError:
                    current_scene = 1
                break

        # Categorize event
        header_clean = header.rstrip(":")
        header_upper = header_clean.upper()
        speaker = None
        direction = None

        if "CAMERA" in header_upper:
            event_type = "camera"
        elif "ACTION" in header_upper:
            event_type = "action"
        elif "SOUND" in header_upper:
            event_type = "sound"
        else:
            event_type = "dialogue"
            # Parse character name and direction e.g. "JULIANA (Desperate, Alarmed)"
            char_match = re.match(r"^([^()]+)(?:\((.*?)\))?$", header_clean)
            if char_match:
                speaker = char_match.group(1).strip()
                direction = char_match.group(2).strip() if char_match.group(2) else None
            else:
                speaker = header_clean

        event = Event(
            index=len(events),
            scene_num=current_scene,
            event_type=event_type,
            speaker=speaker,
            direction=direction,
            content=content,
            start=start_sec,
            end=end_sec,
        )
        events.append(event)

    return Episode(
        episode_num=ep_num,
        title=f"Episode {ep_num}",
        logline=logline,
        continuity_notes=continuity,
        events=events,
    )


def load_all_episodes(scripts_dir: str) -> List[Episode]:
    """Loads and parses all episode script files in a directory sorted by episode number."""
    episodes = []
    files = [f for f in os.listdir(scripts_dir) if f.endswith(".txt")]
    files.sort(key=lambda x: [int(c) if c.isdigit() else c for c in re.split(r"(\d+)", x)])

    for fname in files:
        fpath = os.path.join(scripts_dir, fname)
        ep = parse_episode_file(fpath)
        episodes.append(ep)

    episodes.sort(key=lambda e: e.episode_num)
    return episodes
