# 2. Source Code

This folder contains the complete, production-grade Python project code for the Promo Discovery tool.

## Key Design Principles
- **Standard Library Only:** Zero external dependencies (`pip` install not required). Runs on any standard Python 3.9+ installation.
- **Speed & Scale:** Processes all 50 screenplay episodes (3,727 timestamped events) in ~0.15 seconds.
- **Hard Validity Guarantee:** Code guarantees valid timestamps that land on real shot/line boundaries and never cut mid-sentence.

## Files & Modules

| File | Purpose |
| :--- | :--- |
| `run.py` | Main CLI runner. Orchestrates parse, candidate generation, ranking, and file output. |
| `check_outputs.py` | Automated hard-constraint validator verifying duration (20–60s), exact boundary alignments, and non-overlapping cuts. |
| `app.py` | Standalone interactive web dashboard. |
| `promo_finder/__init__.py` | Package definition. |
| `promo_finder/parse.py` | Robust regex parser for screenplay `.txt` files; extracts float-second timestamps, dialogue, actions, camera, and sound cues. |
| `promo_finder/lexicon.py` | Genre keyword dictionary for 0–3s hooks, conflict verbs, cliffhanger dialogue/sound cues, and standalone filters. |
| `promo_finder/candidates.py` | Generates 20–60s continuous windows, 2-part stitched promos, computes weakest-link scores, and applies Non-Maximum Suppression (NMS). |
| `promo_finder/judge.py` | Optional LLM Judge layer compatible with OpenAI, Gemini, Groq, or Ollama endpoints with local caching in `.cache/`. |
| `promo_finder/rank.py` | Applies entry weights (early-episode preference) and groups promos into Tiers A, B, and C. |

## Execution Commands

### 1. Run Promo Discovery:
```bash
python3 run.py ../../data/scripts --out ../3_Raw_Outputs
```

### 2. Run Hard-Constraint Verification:
```bash
python3 check_outputs.py ../../data/scripts ../3_Raw_Outputs/promos.json
```
Output:
```text
50 episodes checked. 69 promos validated.
ALL CHECKS PASSED.
```
