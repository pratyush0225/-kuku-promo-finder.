"""Hard-constraint checker for generated promo clips.

Verifies:
1. Clip duration is strictly within 20.0s to 60.0s.
2. Timestamps align exactly to event boundaries in the screenplay.
3. No promo cuts a spoken line of dialogue midway.
4. No overlapping segments within a clip.
5. All required metadata fields (hook, cliffhanger, why, rank) are populated.

Usage:
    python check_outputs.py PATH_TO_SCRIPTS outputs/promos.json
"""

import sys
import os
import json
import re
from typing import Dict, List

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from promo_finder.parse import load_all_episodes, parse_timestamp, format_timestamp


def check_promos(scripts_dir: str, promos_json_path: str) -> bool:
    if not os.path.isdir(scripts_dir):
        print(f"Error: Scripts directory '{scripts_dir}' not found.")
        return False

    if not os.path.isfile(promos_json_path):
        print(f"Error: Promos JSON file '{promos_json_path}' not found.")
        return False

    print(f"Loading episodes from {scripts_dir}...")
    episodes = load_all_episodes(scripts_dir)
    ep_map = {e.episode_num: e for e in episodes}

    with open(promos_json_path, "r", encoding="utf-8") as f:
        promos = json.load(f)

    print(f"Validating {len(promos)} promos across {len(episodes)} episodes...")
    errors = []

    for idx, p in enumerate(promos):
        rank = p.get("rank", idx + 1)
        ep_num = p.get("episode")
        duration = p.get("duration_seconds")
        seg_str = p.get("segments_str", "")

        # 1. Episode existence
        if ep_num not in ep_map:
            errors.append(f"Promo #{rank}: Episode {ep_num} not found in scripts.")
            continue
        ep = ep_map[ep_num]

        # 2. Duration constraint: 20s to 60s
        if duration < 19.99 or duration > 60.01:
            errors.append(f"Promo #{rank} (Ep {ep_num}): Invalid duration {duration}s (must be 20-60s).")

        # 3. Parse segments
        segments = []
        for part in seg_str.split("+"):
            part = part.strip()
            times = part.split("-")
            if len(times) == 2:
                s_sec = parse_timestamp(times[0])
                e_sec = parse_timestamp(times[1])
                segments.append((s_sec, e_sec))

        # Check chronology and non-overlap
        for s_idx in range(len(segments) - 1):
            if segments[s_idx][1] > segments[s_idx + 1][0]:
                errors.append(f"Promo #{rank} (Ep {ep_num}): Overlapping segments {segments[s_idx]} and {segments[s_idx+1]}")

        # 4. Check alignment with event boundaries
        event_starts = {e.start for e in ep.events}
        event_ends = {e.end for e in ep.events}

        for s_sec, e_sec in segments:
            # Check if start and end match any event
            start_aligned = any(abs(s_sec - es) < 0.15 for es in event_starts)
            end_aligned = any(abs(e_sec - ee) < 0.15 for ee in event_ends)
            if not start_aligned:
                errors.append(f"Promo #{rank} (Ep {ep_num}): Start timestamp {s_sec}s does not match any event boundary.")
            if not end_aligned:
                errors.append(f"Promo #{rank} (Ep {ep_num}): End timestamp {e_sec}s does not match any event boundary.")

        # 5. Check metadata
        if not p.get("hook"):
            errors.append(f"Promo #{rank}: Missing hook description.")
        if not p.get("cliffhanger"):
            errors.append(f"Promo #{rank}: Missing cliffhanger description.")
        if not p.get("why"):
            errors.append(f"Promo #{rank}: Missing 'why it works' explanation.")

    if errors:
        print("\n❌ VALIDATION FAILED WITH ERRORS:")
        for e in errors[:10]:
            print(f"  - {e}")
        if len(errors) > 10:
            print(f"  ... and {len(errors) - 10} more errors.")
        return False

    print(f"\n{len(episodes)} episodes checked. {len(promos)} promos validated.")
    print("ALL CHECKS PASSED.")
    return True


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python check_outputs.py PATH_TO_SCRIPTS PATH_TO_PROMOS_JSON")
        sys.exit(1)

    scripts_path = sys.argv[1]
    promos_path = sys.argv[2]
    success = check_promos(scripts_path, promos_path)
    sys.exit(0 if success else 1)
